import React, { useState } from "react";
import "./App.css";

import Program1 from "./components/Program1";
import Program2 from "./components/Program2";
import Program3 from "./components/Program3";
import Program4 from "./components/Program4";
import Program5 from "./components/Program5";
import Program6 from "./components/Program6";
import Program7 from "./components/Program7";
import Program8 from "./components/Program8";
import Program9 from "./components/Program9";
import Program10 from "./components/Program10";
import Program11 from "./components/Program11";
import Program12 from "./components/Program12";

const experiments = [
  { id: 1, label: "1. Image Basics (Resize/Crop/Rotate)", Component: Program1 },
  { id: 2, label: "2. Edge Detection & Thresholding", Component: Program2 },
  { id: 3, label: "3. Image Filtering", Component: Program3 },
  { id: 4, label: "4. Contour Detection & Bounding Boxes", Component: Program4 },
  { id: 5, label: "5. Face Detection (Haar Cascade)", Component: Program5 },
  { id: 6, label: "6. Object Tracking (CamShift)", Component: Program6 },
  { id: 7, label: "7. Text Preprocessing", Component: Program7 },
  { id: 8, label: "8. POS Tagging & NER", Component: Program8 },
  { id: 9, label: "9. Sentiment Analysis", Component: Program9 },
  { id: 10, label: "10. Topic Modeling (LDA)", Component: Program10 },
  { id: 11, label: "11. OCR + Summarization", Component: Program11 },
  { id: 12, label: "12. Mini Project: CV + NLP", Component: Program12 },
];

function App() {
  const [activeId, setActiveId] = useState(1);
  const active = experiments.find((e) => e.id === activeId);
  const ActiveComponent = active.Component;

  return (
    <div className="app">
      <header className="app-header">
        <h1>Computer Vision &amp; NLP Lab</h1>
        <p>R23 Regulations · CSE-AI · III B.Tech I Semester</p>
      </header>

      <div className="app-body">
        <nav className="sidebar">
          {experiments.map((exp) => (
            <button
              key={exp.id}
              className={exp.id === activeId ? "nav-item active" : "nav-item"}
              onClick={() => setActiveId(exp.id)}
            >
              {exp.label}
            </button>
          ))}
        </nav>

        <main className="content">
          <ActiveComponent />
        </main>
      </div>
    </div>
  );
}

export default App;
